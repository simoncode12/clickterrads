<?php
// File: /admin/index.php
header('Location: login.php');
exit();
